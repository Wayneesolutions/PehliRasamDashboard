const o="/assets/logo-7husDTuK.png";export{o as l};
